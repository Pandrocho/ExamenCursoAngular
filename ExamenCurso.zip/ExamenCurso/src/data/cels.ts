export const DATA= [
  {
          _id: "633b5608a1f43e001dd62735",
          androidEnterpriseRecommended: false,
          createdAt: "2022-10-03T21:37:12.522Z",
          deviceGroup: "phone",
          deviceName: "Galaxy A04s",
          modelCode: "SM-A047F, SM-A047M",
          moderationState: "published",
          os: "Android",
          osVersion: "na",
          slug: "633b5608a1f43e001dd62735",
          updatedAt: "2023-04-05T17:19:51.342Z",
          knoxVault: false,
          vals: {
            isTizen: false,
            versionNumber: "3.9" },
          ui: {
              _id: "5f33576e3a4952008ac70386",
              title: "Android - Secured by Knox"
          }
      },
      {
          _id: "63042a9444f76b001df82c63",
          androidEnterpriseRecommended: false,
          createdAt: "2022-08-23T01:17:08.187Z",
          deviceGroup: "phone",
          deviceName: "Galaxy A12",
          modelCode: "SM-A127M, SM-A127F",
          moderationState: "published",
          os: "Android",
          osVersion: "na",
          slug: "63042a9444f76b001df82c63",
          updatedAt: "2023-01-10T19:38:13.123Z",
          knoxVault: false,
          vals: {
            isTizen: false,
            versionNumber: "3.9" },
          ui: {
              _id: "5f33576e3a4952008ac70386",
              title: "Android - Secured by Knox"
          }
      },
      {
          _id: "62449d9fe676cc001d2189f5",
          androidEnterpriseRecommende: false,
          createdAt: "2022-03-30T18:12:47.884Z",
          deviceGroup: "phone",
          deviceName: "Galaxy A13",
          modelCode: "SM-A135F, SM-A135U, SM-A135M, SM-A135N, SM-A137F, SM-A135U1",
          moderationState: "published",
          os: "Android",
          osVersion: "na",
          slug: "62449d9fe676cc001d2189f5",
          updatedAt: "2023-02-09T07:42:15.963Z",
          knoxVault: false,
          vals: {
            isTizen: false,
            versionNumber: "3.9" },
          ui: {
              _id: "5f33576e3a4952008ac70386",
              title: "Android - Secured by Knox"
          }
      },
  ]
