export interface ObtenerInfoResponse
{
            _id: string,
            androidEnterpriseRecommended: boolean,
            createdAt: any,
            deviceGroup: string,
            deviceName: string,
            modelCode: string,
            moderationState:string,
            os: string,
            osVersion: string,
            slug: string,
            updatedAt: any,
            knoxVault: boolean,
            vals: {
                isTizen: boolean,
                versionNumber: string
            },
            ui: {
                _id: string,
                title: string
            }
}
