export interface ObtenerInfoRequest
{
  deviceGroup: string,
  deviceName: string,
  modelCode: string,
  os: string,
  osVersion: string,
}
