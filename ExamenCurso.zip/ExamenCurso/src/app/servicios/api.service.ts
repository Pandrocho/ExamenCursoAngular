import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
api:string
cabecero={
  'content-Type':'application/json',
  'Authorization':''
}

constructor(private http:HttpClient) {
this.api=environment.api;
  }
getCategorias(page:any):Observable<any>{
return this.http.get(`${this.api}?page={page}`)//,{headers: this.cabecero})
}
  /*getCategoriasPorId(id:any):Observable<any>{
return this.http.get(`${this.api}users/${id}`,{headers: this.cabecero})
  }*/



}
