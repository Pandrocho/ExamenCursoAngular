import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//Material
import { MatButtonModule } from '@angular/material/button';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import {MatCheckboxModule} from  '@angular/material/checkbox'
import {MatTabsModule} from '@angular/material/tabs';
import {MatDialogModule} from '@angular/material/dialog';
import { HttpClientModule } from '@angular/common/http';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatCardModule} from '@angular/material/card';
import { NavComponent } from './Componentes/nav/nav.component';
import { FiltrosComponent } from './Componentes/filtros/filtros.component';
import { TablaComponent } from './Componentes/tabla/tabla.component';
import { MainComponent } from './Componentes/main/main.component';
import { FooterComponent } from './Componentes/footer/footer.component';
import { BodyComponent } from './Componentes/body/body.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete'
@NgModule({
  declarations: [
    AppComponent,
    NavComponent,
    FiltrosComponent,
    TablaComponent,
    MainComponent,
    FooterComponent,
    BodyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    NgbModule,
    MatButtonModule,
    MatIconModule,
    HttpClientModule,
    NgbModule,
    MatInputModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatDialogModule,
    MatExpansionModule,
    MatCardModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    FormsModule,
    MatAutocompleteModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
