import { Component , OnInit} from '@angular/core';
//import { ObtenerInfoResponse } from 'src/app/interfaces/obtener-info-response';
import { ApiService } from 'src/app/servicios/api.service';
import { ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import  data from '../../../assets/data.json'
//import {DATA} from '../../../data/cels'

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {
 public celulares = data.data;
 total:any;
 por_pagina:any;
 page=1;
 links:number;
paginas:Array<any>=[];

constructor(private apiservice:ApiService, private router:ActivatedRoute, private httpClient:HttpClient){
}
ngOnInit(): void {
 console.log(this.celulares);

}

/*peticion(){
this.apiservice.getCategorias().subscribe(
 { next:peticion =>{
  this.datos=peticion.data;
 },error:error=>{

  console.log("Error: "+JSON.stringify(error));
 }});
}*/
public firstWay():void{
  console.log("First");
  //this.celulares= data.data;
}

}
