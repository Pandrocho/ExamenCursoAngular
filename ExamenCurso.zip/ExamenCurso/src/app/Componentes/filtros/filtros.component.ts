import {Component, OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import {ThemePalette} from '@angular/material/core';
export interface User {
  name: string;
}
export interface Task {

  color: ThemePalette;
  subtasks?: Task[];
}
@Component({
  selector: 'app-filtros',
  templateUrl: './filtros.component.html',
  styleUrls: ['./filtros.component.css']
})
export class FiltrosComponent implements OnInit{
  task: Task = {
    color: 'primary'}
  myControl = new FormControl<string | User>('');
  options: User[] = [
  {name: 'Galaxy A04s'},
  {name: 'Galaxy A12'},
  {name: 'Galaxy Note10 Lite'},
  {name: 'Galaxy Note20'},
  {name: 'Galaxy Tab A8'},
  {name: 'Galaxy Tab Active3'},
  {name: 'Galaxy Tab Active4 Pro'},
  {name: 'Gear 360 (2017)'},
  {name: 'Gear 360 Pro'},
  {name: 'Watch4 Classic 42mm'}];
  filteredOptions: Observable<User[]>;
  opcion1=true;
opcion2=false;
opcion3=false;
  constructor(){

  }
  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges.pipe(
      startWith(''),
      map(value => {
        const name = typeof value === 'string' ? value : value?.name;
        return name ? this._filter(name as string) : this.options.slice();
      }),
    );
  }
  enviar(){

  }
  displayFn(user: User): string {
    return user && user.name ? user.name : '';
  }

  private _filter(name: string): User[] {
    const filterValue = name.toLowerCase();

    return this.options.filter(option => option.name.toLowerCase().includes(filterValue));
  }
}
