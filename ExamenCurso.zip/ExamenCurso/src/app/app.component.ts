import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'ExamenCurso';
  constructor(private router:Router){}
  ngOnInit(): void {

  this.crearLocal();
      }

      crearLocal(){
        if (typeof(Storage)!== 'undefined') {
          localStorage.setItem("usuario","Alexis Galvan");
        } else {
        console.log("no se puede");
        }
          }


    }
